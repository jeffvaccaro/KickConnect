import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-O3PD5SAC.js";
import "./chunk-2G2LOODL.js";
import "./chunk-AYTBD7VK.js";
import "./chunk-DBZEFMJN.js";
import "./chunk-XP5MLFGJ.js";
import "./chunk-5XXOF2XJ.js";
import "./chunk-WDW2G73A.js";
import "./chunk-JJZWSLEO.js";
import "./chunk-M3HR6BUY.js";
import "./chunk-HXGJ4U2M.js";
import "./chunk-AHTD7YAV.js";
import "./chunk-KCWIIA2R.js";
import "./chunk-EYFAA723.js";
import "./chunk-5UX3UCM4.js";
import "./chunk-WYBF7PXX.js";
import "./chunk-E3QC5ZTU.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-TXDUYLVM.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
