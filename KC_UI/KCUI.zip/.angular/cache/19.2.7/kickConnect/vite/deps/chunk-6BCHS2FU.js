import {
  InjectionToken
} from "./chunk-E3QC5ZTU.js";

// node_modules/@angular/material/fesm2022/input-value-accessor-16c2d528.mjs
var MAT_INPUT_VALUE_ACCESSOR = new InjectionToken("MAT_INPUT_VALUE_ACCESSOR");

export {
  MAT_INPUT_VALUE_ACCESSOR
};
//# sourceMappingURL=chunk-6BCHS2FU.js.map
