export enum HtmlGeneratedTypes {
    Text = 1,
    Image = 2,
    Video = 3
}
