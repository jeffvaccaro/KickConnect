import { Component } from '@angular/core';

@Component({
    selector: 'app-video-library',
    imports: [],
    templateUrl: './video-library.component.html',
    styleUrl: './video-library.component.scss'
})
export class VideoLibraryComponent {

}
