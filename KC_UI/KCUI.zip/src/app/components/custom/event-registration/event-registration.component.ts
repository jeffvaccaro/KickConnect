import { Component } from '@angular/core';

@Component({
    selector: 'app-event-registration',
    imports: [],
    templateUrl: './event-registration.component.html',
    styleUrl: './event-registration.component.scss'
})
export class EventRegistrationComponent {

}
