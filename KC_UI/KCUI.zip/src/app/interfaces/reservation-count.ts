export interface IReservationCount {
    reservationCountId: number;
    reservationCountValue: string;
}