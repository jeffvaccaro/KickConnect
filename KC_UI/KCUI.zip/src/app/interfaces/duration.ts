export interface IDuration {
    durationValue: number;
    durationText: string;
}
