export interface Role {
    roleId: number;
    roleName: string;
    roleDescription: string;
    roleOrderId: number;
    disabled: false;
  }