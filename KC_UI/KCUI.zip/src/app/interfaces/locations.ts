export interface ILocations {
    locationId: number;
    accountId: number;
    locationName: string;
    disabled: boolean;
}
