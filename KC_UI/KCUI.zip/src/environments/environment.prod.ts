// environment.prod.ts
export const environment = {
  production: true,
  apiUrl: 'https://api.kickconnect.net/'
};
  